package com.trendsetter.deck_out.Login_Signup;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.goodiebag.pinview.Pinview;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.trendsetter.deck_out.Extra.Emaildata;
import com.trendsetter.deck_out.Extra.Emailverification;
import com.trendsetter.deck_out.R;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import cn.iwgang.countdownview.CountdownView;


public class Regverifictaion extends AppCompatActivity {

    Button resendotpbtn;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mcallback;
    PhoneAuthProvider.ForceResendingToken mResendToken = null;
    FirebaseAuth auth;
    Pinview phonepin , emailpin;
    String Phoneno , emailid ;
    int phoneverificationcode , emailverificationcode;
    ProgressBar phonepbar , emailpbar;
    Button phoneverifybtn , emailverifybtn ;
    PhoneAuthCredential credential;
    String mVerificationId , uid;
    ImageView infobtn;
    CountdownView mCvCountdownView;
    Emaildata emaildata = new Emaildata();
    int funccounter = 0;
    RelativeLayout parentrootlayout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.regverificationlayout);
        Toolbar toolbar = (Toolbar) findViewById(R.id.regverifytoolbar);
        setSupportActionBar(toolbar);
        uid = getIntent().getExtras().getString("uid");
        emailid =  getIntent().getExtras().getString("useremail");
        Phoneno =  getIntent().getExtras().getString("userphoneno");

        auth = FirebaseAuth.getInstance();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Verification");
        toolbar.setTitleTextColor(Color.WHITE);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        resendotpbtn = findViewById(R.id.resendotpbtn);

        phonepbar = findViewById(R.id.phoneprogressbar);
        emailpbar = findViewById(R.id.emailidprogressbar);

        phoneverifybtn = findViewById(R.id.phoneveriftbtn);
        emailverifybtn = findViewById(R.id.emailverifybtn);
        parentrootlayout = findViewById(R.id.regrootlayout);

        emailverifybtn.setEnabled(false);
        emailverifybtn.setBackgroundResource(R.drawable.buttonbluefade);

        infobtn = findViewById(R.id.regverifyinfobtn);
        infobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog versiondetailpannel = new Dialog(Regverifictaion.this);
                versiondetailpannel.requestWindowFeature(Window.FEATURE_NO_TITLE);
                versiondetailpannel.getWindow().setWindowAnimations(R.style.animateddialog);
                versiondetailpannel.setCanceledOnTouchOutside(false);
                versiondetailpannel.setCancelable(true);
                versiondetailpannel.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                versiondetailpannel.setContentView(R.layout.versiondetaillayout);

                TextView versiondetailtxt = versiondetailpannel.findViewById(R.id.versiondetail);
                versiondetailtxt.setText(Html.fromHtml("<html> <body> <p> <h2>  Email ID and Phone No. Verification   </h2> </p> <br>  <p> As this Verification is necessary for us to Register you as Genuine user and also to avoid login from bot user. <br><br>Thank You!!</p> </body> </html>"));

                ImageView changepannelclosebtn = versiondetailpannel.findViewById(R.id.softwareversiondialogclose);
                changepannelclosebtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        versiondetailpannel.dismiss();
                    }
                });
                versiondetailpannel.show();
                Window window = versiondetailpannel.getWindow();
                window.addFlags(View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        |View.SYSTEM_UI_FLAG_FULLSCREEN
                        |View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        |View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
                window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            }
        });

        mCvCountdownView = (CountdownView) findViewById(R.id.seccounter);
        startcounter();


        phoneverifybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        emailverifybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (emailpin.getValue().trim().length() == 0) {
                    Snackbar snackbar = Snackbar
                            .make(parentrootlayout, "OTP not be empty", Snackbar.LENGTH_LONG);
                    snackbar.getView().setBackgroundColor(Color.RED);
                    TextView textView = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    snackbar.show();
                }

                else
               {
                    checkemailidotp(emailpin.getValue());
                }

            }
        });


        resendotpbtn = findViewById(R.id.resendotpbtn);
        resendotpbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resendotpbtn.setBackgroundResource(R.drawable.resendbtngrey);
                resendotpbtn.setEnabled(false);
                resendsms(Phoneno);
                startcounter();
            }
        });

        phonepin = (Pinview) findViewById(R.id.phonepinview);
        phonepin.setPinViewEventListener(new Pinview.PinViewEventListener() {
            @Override
            public void onDataEntered(Pinview pinview, boolean fromUser) {
                //Make api calls here or what not
                Toast.makeText(Regverifictaion.this, pinview.getValue(), Toast.LENGTH_SHORT).show();
            }
        });

        emailpin = findViewById(R.id.emailidpinview);
        emailpin.setEnabled(false);
        emailpin.setPinViewEventListener(new Pinview.PinViewEventListener() {
            @Override
            public void onDataEntered(Pinview pinview, boolean fromUser) {
                //Make api calls here or what not
             emailpbar.setVisibility(View.VISIBLE);
            }
        });


        mcallback = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {
                signinwithphone(credential);
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {

            }

            @Override
            public void onCodeSent(String verificationId,
                                   PhoneAuthProvider.ForceResendingToken token) {
                if(mResendToken == null) {
                    mResendToken = token;
                }


                mVerificationId = verificationId;

            }
        };
    }

    @Override
    protected void onStart() {
        super.onStart();
        if(funccounter == 0)
       new sendotp().execute();
        funccounter+=1;
    }

    @Override
    public void onResume() {
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter("otp"));
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp")) {
                final String message = intent.getStringExtra("message");

                phonepin.setValue(message.trim().substring(0,6));

                phonepin.setEnabled(false);
                phoneverifybtn.setBackgroundResource(R.drawable.buttonbluefade);
                phoneverifybtn.setText("Verified");
                phoneverifybtn.setEnabled(false);
                sendemail();

                emailverifybtn.setBackgroundResource(R.drawable.buttonroundcornerblue);
                emailpin.setEnabled(true);
                emailverifybtn.setEnabled(true);

                resendotpbtn.setEnabled(false);
                resendotpbtn.setBackgroundResource(R.drawable.resendbtngrey);

                credential = PhoneAuthProvider.getCredential(mVerificationId,message.trim().substring(0,6));
            }
        }
    };


    public void  setsms(String signupmobno)
    {
        PhoneAuthProvider.getInstance().verifyPhoneNumber("+977"+signupmobno,60, TimeUnit.SECONDS,this,mcallback);
        Toast.makeText(Regverifictaion.this,"sending sms to +977"+signupmobno,Toast.LENGTH_SHORT).show();
    }

    public void resendsms(String signupmobno)
    {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                "+977"+signupmobno.trim(),
                30 ,
                TimeUnit.SECONDS,
                this,
                mcallback,
                mResendToken);


    }

    private void signinwithphone(PhoneAuthCredential credential)
    {
        auth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(Regverifictaion.this,"user auth sucessfully",Toast.LENGTH_SHORT).show();
                    FirebaseUser user = task.getResult().getUser();
                }

                else
                {
                    Toast.makeText(Regverifictaion.this,"user auth failed",Toast.LENGTH_SHORT).show();
                }

                phonepbar.setVisibility(View.GONE);
                phoneverifybtn.setEnabled(false);
                phoneverifybtn.setText("Verified");
                phoneverifybtn.setBackgroundResource(R.drawable.resendbtngrey);
            }
        });
    }




    private void sendemail()
    {
        String email = emailid;

        final List<String> toEmail = Arrays.asList(email.split("\\s*,\\s*"));

        Toast.makeText(Regverifictaion.this,"sending email",Toast.LENGTH_SHORT).show();


        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    Emailverification androidEmail = new Emailverification("contact.dreamhunterztech@gmail.com",
                            "Suwas1zpunk", toEmail, "Email Verification Code",
                            emaildata.getdata());
                    androidEmail.createEmailMessage();
                    androidEmail.sendEmail();
                } catch (Exception e) {
                    System.out.print(e);
                }

            }

        }).start();
        setemailotp();
    }


    public class sendotp extends AsyncTask
    {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
           phonepbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected Object doInBackground(Object[] params) {

            try {
                Thread.sleep(3000);
            }
            catch (InterruptedException e) {

                e.printStackTrace();

            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            setsms(Phoneno);

        }
    }


    private void startcounter()
    {
        mCvCountdownView.start(30000);
        mCvCountdownView.setOnCountdownEndListener(new CountdownView.OnCountdownEndListener() {
            @Override
            public void onEnd(CountdownView cv) {
                resendotpbtn.setBackgroundResource(R.drawable.resendbtnred);
                resendotpbtn.setEnabled(true);
            }
        });

    }


    private void setemailotp()
    {
        DatabaseReference otpref = FirebaseDatabase.getInstance().getReference("datarecords/deckoutusers/Client/"+uid);
        otpref.child("emailotp").setValue(emaildata.getOtp());
    }

    private void checkemailidotp(String otp)
    {

        DatabaseReference otpref = FirebaseDatabase.getInstance().getReference("datarecords/deckoutusers/Client/"+uid);
        otpref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("emailotp").getValue().toString().equals(otp))
                {
                    AlertDialog.Builder message = new AlertDialog.Builder(Regverifictaion.this);
                    message.setTitle("Verified Sucessfully");
                    AlertDialog alert;
                    message.setMessage("\nNow Login with your Phone No. / Emaild to use our service\n\nThank You!!!");
                    message.setCancelable(false);
                    message.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    });
                    alert = message.create();
                    alert.show();
                }

                else
                {
                    AlertDialog.Builder message = new AlertDialog.Builder(Regverifictaion.this);
                    message.setTitle("Otp not matched");
                    AlertDialog alert;
                    message.setMessage("\nPlease Enter Correct OTP recieved by your email id.");
                    message.setCancelable(true);
                    message.setNegativeButton("Ok",null);
                    alert = message.create();
                    alert.show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }




    private void checkverification(String useridtxt)
    {

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference checkphoneidref = database.getReference("https://deck-out.firebaseio.com/datarecords/deckoutusers/Client/"+useridtxt);

        checkphoneidref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }



}
