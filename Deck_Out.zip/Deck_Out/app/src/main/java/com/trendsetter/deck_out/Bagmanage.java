/*
package com.dreamhunterztech.deck_out;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

*/
/**
 * Created by Dreamer on 18-11-2017.
 *//*


public class Bagmanage extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.baglayout);

        Toolbar toolbar = (Toolbar) findViewById(R.id.bagtoolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("2 items in your bag");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
*/
