package com.trendsetter.deck_out.Payment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.trendsetter.deck_out.R;


public class paymentproceed extends Fragment {


    TextView   proceedaddresstxt;
    RelativeLayout onlinepayment;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.paymentproceedlayout, container, false);
        proceedaddresstxt = view.findViewById(R.id.proceedaddresstxt);
        proceedaddresstxt.setText(Html.fromHtml("#145 near PNB , Bypass , Solan <br><br> HIMACHAL PRADESH -  173222 <br><br> Phone - 8765438756"));

        onlinepayment = view.findViewById(R.id.paymentproceedonlinepayment);
        onlinepayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity() , Redirecttopayment.class));
            }
        });
        return view;
    }
}
