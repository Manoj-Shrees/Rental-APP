package com.trendsetter.deck_out.Payment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.trendsetter.deck_out.R;

public class paymentreview extends Fragment {

    TextView reviewaddresstxt , addresseditbtn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.paymentreviewlayout, container, false);
        reviewaddresstxt = view.findViewById(R.id.reviewaddresstxt);
        reviewaddresstxt.setText(Html.fromHtml("#145 near PNB , Bypass , Solan <br><br> HIMACHAL PRADESH -  173222 <br><br> Phone - 8765438756"));
        addresseditbtn = view.findViewById(R.id.addresseditbtn);
        addresseditbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                /*transaction.setCustomAnimations(R.anim.slide_right_enter, R.anim.fade_out);*/
                transaction.replace(R.id.paymentfragcontainer, new paymentfragaddress());
                transaction.addToBackStack(null).commit();
                getActivity().setTitle("Confrim");
            }
        });
        return view;
    }





}
