package com.trendsetter.deck_out.Homepage;

public class productshortcutlistgetdata  {

    private String name;
    private String ads1;
    private String ads2;
    private String img1;
    private String img2;
    private String img3;
    private String img4;
    private String img5;
    private String img6;
    private String img7;
    private String img8;
    private String img9;


    productshortcutlistgetdata()
    {

    }

    productshortcutlistgetdata(  String name, String ads1, String ads2, String img1, String img2, String img3, String img4, String img5, String img6, String img7, String img8, String img9)
    {
        this.name = name;
        this.ads1 = ads1;
        this.ads2 = ads2;
        this.img1 = img1;
        this.img2 = img2;
        this.img3 = img3;
        this.img4 = img4;
        this.img5 = img5;
        this.img6 = img6;
        this.img7 = img7;
        this.img8 = img8;
        this.img9 = img9;

    }

    public String getName() {
        return name;
    }

    public String getAds1() {
        return ads1;
    }

    public String getAds2() {
        return ads2;
    }

    public String getImg1() {
        return img1;
    }

    public String getImg2() {
        return img2;
    }

    public String getImg3() {
        return img3;
    }

    public String getImg4() {
        return img4;
    }

    public String getImg5() {
        return img5;
    }

    public String getImg6() {
        return img6;
    }

    public String getImg7() {
        return img7;
    }

    public String getImg8() {
        return img8;
    }


    public String getImg9() {
        return img9;
    }
}
