package com.trendsetter.deck_out.Extra;


public class Constant {

    public static final long API_CONNECTION_TIMEOUT = 1201;
    public static final long API_READ_TIMEOUT = 901;

    public static final String BASE_URL =   "https://deckout.000webhostapp.com/";
    public static final String SERVER_main_folder = "payment/";

}
