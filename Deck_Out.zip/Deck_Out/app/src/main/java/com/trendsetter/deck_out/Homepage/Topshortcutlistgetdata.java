package com.trendsetter.deck_out.Homepage;

public class Topshortcutlistgetdata {

        private String shortcutname;
        private String shortcuturl;

        public Topshortcutlistgetdata()
        {

        }


        public Topshortcutlistgetdata(String shortcutname , String shortcuturl)
        {
            this.shortcutname = shortcutname;
            this.shortcuturl = shortcuturl;
        }


    public String getShortcutname() {
        return shortcutname;
    }

    public String getShortcuturl() {
        return shortcuturl;
    }
}
