package com.trendsetter.deck_out.Login_Signup;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.trendsetter.deck_out.R;

public class Loginsocial extends AppCompatActivity {

    String  useremail , userprofilepic;
    ImageView userpics;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginsociallayout);

         useremail = getIntent().getExtras().getString("useremail");
         userprofilepic =  getIntent().getExtras().getString("userimgurl");
         userpics = findViewById(R.id.userpic);

    }

}
