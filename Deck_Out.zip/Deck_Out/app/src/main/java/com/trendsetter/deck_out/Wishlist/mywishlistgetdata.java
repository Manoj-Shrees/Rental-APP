package com.trendsetter.deck_out.Wishlist;

public class mywishlistgetdata {
    private String name;
    private String size_available;
    private String description;
    private String price;
    private String no_of_views;
    private String product_id;
    private String product_likes;
    private String total_ratings;
    private String imgurl1;
    private String imgurl2;
    private String imgurl3;
    private String imgurl4;
    private String imgurl5;
    private String imgurl6;
    private String dress_code;
    private String dress_sizetitle;

    mywishlistgetdata()
    {

    }

    mywishlistgetdata(String name, String size_available, String description , String dress_code , String dress_sizetitle,String product_likes , String price, String no_of_views, String product_id, String total_ratings , String imgurl1, String imgurl2, String imgurl3, String imgurl4, String imgurl5, String imgurl6)
    {
        this.name = name;
        this.description = description;
        this.size_available = size_available;
        this.price = price;
        this.no_of_views = no_of_views;
        this.product_id = product_id;
        this.total_ratings = total_ratings;
        this.product_likes = product_likes;
        this.imgurl1 = imgurl1;
        this.imgurl2 = imgurl2;
        this.imgurl3 = imgurl3;
        this.imgurl4 = imgurl4;
        this.imgurl5 = imgurl5;
        this.imgurl6 = imgurl6;
        this.dress_code = dress_code;
        this.dress_sizetitle = dress_sizetitle;
    }


    public String getName() {
        return name;
    }

    public String getProduct_likes() {
        return product_likes;
    }

    public String getDress_sizetitle() {
        return dress_sizetitle;
    }

    public String getDress_code() {
        return dress_code;
    }

    public String getDescription() {
        return description;
    }

    public String getImgurl1() {
        return imgurl1;
    }

    public String getImgurl2() {
        return imgurl2;
    }

    public String getImgurl3() {
        return imgurl3;
    }

    public String getImgurl4() {
        return imgurl4;
    }

    public String getImgurl5() {
        return imgurl5;
    }

    public String getImgurl6() {
        return imgurl6;
    }

    public String getNo_of_views() {
        return no_of_views;
    }

    public String getPrice() {
        return price;
    }

    public String getProduct_id() {
        return product_id;
    }

    public String getSize_available() {
        return size_available;
    }

    public String getTotal_ratings() {
        return total_ratings;
    }

}
