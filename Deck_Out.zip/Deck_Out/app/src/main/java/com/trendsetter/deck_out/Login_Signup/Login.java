package com.trendsetter.deck_out.Login_Signup;


import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.internal.ImageRequest;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lsjwzh.widget.materialloadingprogressbar.CircleProgressBar;
import com.trendsetter.deck_out.Extra.Datechecker;
import com.trendsetter.deck_out.Extra.Drawablesdata;
import com.trendsetter.deck_out.Homepage.homepage;
import com.trendsetter.deck_out.Legals.Legal;
import com.trendsetter.deck_out.Legals.legalexplistadapter;
import com.trendsetter.deck_out.Productdetails.Productdetail;
import com.trendsetter.deck_out.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.concurrent.Executor;

import static android.content.Context.MODE_PRIVATE;
import static com.facebook.FacebookSdk.getApplicationContext;
import static com.facebook.GraphRequest.TAG;

public class Login extends Fragment {

    Button switchsignupbtn , loginbtn ;
    ImageView facebookloginbtn , googleloginbtn;
    EditText loginid , loginpass;
    CallbackManager callbackManager;
    private GoogleApiClient mGoogleApiClient;
    GoogleSignInOptions gso;
    private static final int RC_SIGN_IN = 007;
    private boolean checkemailblock = false , checkphnoblock = false  , isNumeric;
    Drawable erroricon;
    CircleProgressBar loginprogressbar;
    Handler handler = new Handler();
    Runnable runnable;
    int finalI = 0 , logincounter=0;
    private SharedPreferences sp;
    private   SharedPreferences.Editor Ed;

    private FirebaseAuth mAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        sp=getActivity().getSharedPreferences("Login", MODE_PRIVATE);
        Ed=sp.edit();

        callbackManager = CallbackManager.Factory.create();
        mAuth = FirebaseAuth.getInstance();
        FacebookSdk.sdkInitialize(getApplicationContext());

         gso =  new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("792473902163-gh6j1uej2gmbih2kcior2sj6fbocevvl.apps.googleusercontent.com")
                .requestProfile()
                .requestEmail()
                .build();



        mGoogleApiClient = new GoogleApiClient.Builder(getApplicationContext())
                .enableAutoManage(getActivity(), new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

                    }
                })
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();


        erroricon = new Drawablesdata().getdrawablewhite(getActivity());
        View view = inflater.inflate(R.layout.loginpageloginlayout, container, false);
        switchsignupbtn = view.findViewById(R.id.switchsignup);
        loginid = view.findViewById(R.id.loginid);
        loginpass = view.findViewById(R.id.loginpass);
        loginbtn = view.findViewById(R.id.loginbtn);
        facebookloginbtn = view.findViewById(R.id.facebookloginbtn);
        googleloginbtn = view.findViewById(R.id.googleloginbtn);
        loginprogressbar = view.findViewById(R.id.loginprogressBar);

        instlistener();

        return view;
    }



    private void instlistener()
    {
        switchsignupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.setCustomAnimations(R.anim.dialog_in,R.anim.dialog_out);
                transaction.replace(R.id.loginpagefragmentcontainer, new Signup());
                transaction.addToBackStack(null).commit();
            }
        });



        loginbtn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                if(loginid.getText().toString().trim().length() == 0)
                {
                    loginid.setError("is Empty",erroricon);
                    logincounter+=1;
                }

                if(loginpass.getText().toString().trim().length() == 0)
                {
                    loginpass.setError("is Empty",erroricon);
                    logincounter+=1;
                }

                if(logincounter == 0)
                {
                    setprogress();
                    proceedlogin();
                }

             //Log.e(">>curr date" , " , "+ new Datechecker().checkdate());

            }
        });


        facebookloginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LoginManager.getInstance().logInWithReadPermissions(getActivity(), Arrays.asList("email","user_photos","public_profile"));

                LoginManager.getInstance().registerCallback(callbackManager,
                        new FacebookCallback<LoginResult>() {
                            @Override
                            public void onSuccess(LoginResult loginResult) {
                                setFacebookData(loginResult);

                            }

                            @Override
                            public void onCancel() {
                                Toast.makeText(getApplicationContext(), "Login Cancel", Toast.LENGTH_LONG).show();
                            }

                            @Override
                            public void onError(FacebookException exception) {
                                Toast.makeText(getApplicationContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        });

            }
        });

        googleloginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
                startActivityForResult(signInIntent, RC_SIGN_IN);
            }
        });




    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }


    @Override
    public void onPause() {
        super.onPause();
        mGoogleApiClient.stopAutoManage(getActivity());
        mGoogleApiClient.disconnect();
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);

    }


    private void handleFacebookAccessToken(AccessToken token) {

        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener((Executor) this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            Toast.makeText(getApplicationContext(), "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }

                        // ...
                    }
                });
    }


    private void updateUI(FirebaseUser user) {
        if (user != null) {
           Toast.makeText(getApplicationContext(),user.toString(),Toast.LENGTH_SHORT).show();

        }

        else {

        }
    }

    private void setFacebookData(final LoginResult loginResult) {
        GraphRequest request = GraphRequest.newMeRequest(
                loginResult.getAccessToken(),
                new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                        // Application code
                        try {
                            Log.i("Response", response.toString());

                            String email = response.getJSONObject().getString("email");
                            String profileURL = "";
                            if (Profile.getCurrentProfile() != null) {
                                profileURL = ImageRequest.getProfilePictureUri(Profile.getCurrentProfile().getId(), 400, 400).toString();
                            }

                            else {
                                profileURL = "N/A";
                            }

                            Log.e(">>loginwithfb" , email+"  , "+profileURL);

                          // loginwithsocial(email , profileURL);

                            //TODO put your code here
                        } catch (JSONException e) {
                            Toast.makeText(getActivity(), "failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }



        private void checkblockeduseremail(final String id)
    {
        final DatabaseReference checkdata = FirebaseDatabase.getInstance().getReference("blockedusers").child("emailid");
        checkdata.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild(id))
                {
                    AlertDialog.Builder message = new AlertDialog.Builder(getContext());
                    message.setTitle("Message");
                    AlertDialog alert;
                    message.setMessage("You have been Blocked By Deck Out .");
                    message.setCancelable(true);

                    message.setNegativeButton("Ok",null);
                    alert = message.create();
                    alert.show();
                }

                else
                {
                    getuid(id  ,  loginpass.getText().toString().trim());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void checkblockeduserphoneno(final String id)
    {
        final DatabaseReference checkdata = FirebaseDatabase.getInstance().getReference("blockedusers").child("phno");
        checkdata.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild(id))
                {
                    AlertDialog.Builder message = new AlertDialog.Builder(getContext());
                    message.setTitle("Message");
                    AlertDialog alert;
                    message.setMessage("You have been Blocked By Deck Out .");
                    message.setCancelable(true);

                    message.setNegativeButton("Ok",null);
                    alert = message.create();
                    alert.show();
                }

                else
                {
                    getuid(id ,  loginpass.getText().toString().trim());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    private void loginuserwithemail(String uid , String id , String password)
    {
        final DatabaseReference checkuid = FirebaseDatabase.getInstance().getReference("datarecords/deckoutusers/Client/"+uid.trim());
        checkuid.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

             if(dataSnapshot.child("Emailid").getValue().equals(id.replace("~", "@").replace("`", ".")))
             {
                DatabaseReference checkpass = FirebaseDatabase.getInstance().getReference("datarecords/deckoutusers/Client/"+uid.trim());
                checkpass.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.child("Password").getValue().equals(password)) {
                            startActivity(new Intent(getContext() , homepage.class).putExtra("userid",uid));
                            Ed.putString("userid", uid);
                            Ed.commit();
                        }

                        else
                        {

                            AlertDialog.Builder message = new AlertDialog.Builder(getContext());
                            message.setTitle("Password not matched");
                            AlertDialog alert;
                            message.setMessage("\nDo you want to reset Password ?");
                            message.setCancelable(true);

                            message.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                   startActivity(new Intent(getContext() , Loginforgotpass.class).putExtra("uid",uid));
                                }
                            });
                            message.setNegativeButton("No",null);
                            alert = message.create();
                            alert.show();
                        }


                        handler.removeCallbacks(runnable);
                        loginprogressbar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
             }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void loginuserwithphone( String uid , String id , String password)
    {


        final DatabaseReference checkuid = FirebaseDatabase.getInstance().getReference("datarecords/deckoutusers/Client/"+uid);
        checkuid.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.child("Mobno").getValue().equals(""+id))
                {
                    DatabaseReference checkpass = FirebaseDatabase.getInstance().getReference("datarecords/deckoutusers/Client/"+uid);
                    checkpass.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if(dataSnapshot.child("Password").getValue().equals(password)) {
                                startActivity(new Intent(getContext() , homepage.class).putExtra("userid",uid));
                                Ed.putString("userid", uid);
                                Ed.commit();
                            }

                            else
                            {

                                AlertDialog.Builder message = new AlertDialog.Builder(getContext());
                                message.setTitle("Password not matched");
                                AlertDialog alert;
                                message.setMessage("\nDo you want to reset Password ?");
                                message.setCancelable(true);

                                message.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });
                                message.setNegativeButton("No",null);
                                alert = message.create();
                                alert.show();
                            }


                            handler.removeCallbacks(runnable);
                            loginprogressbar.setVisibility(View.GONE);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }



    private void loginwithsocial(String id , String picurl)
    {
        startActivity(new Intent(getContext() , Loginsocial.class).putExtra("useremail" , id ).putExtra("userimgurl" , picurl));
    }

    private void getuid(String id , String pass)
    {
        final DatabaseReference checkdata = FirebaseDatabase.getInstance().getReference("dataindex/userindex/client");
        if(isNumeric)
        {
            checkdata.child("Phoneno").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child(id).exists()) {

                        loginuserwithphone(dataSnapshot.child(id).getValue().toString() ,id , pass);
                    }

                    else
                        {

                        handler.removeCallbacks(runnable);
                        loginprogressbar.setVisibility(View.GONE);
                        AlertDialog.Builder message = new AlertDialog.Builder(getContext());
                        message.setTitle("Message");
                        AlertDialog alert;
                        message.setMessage("Please Sign Up to use our service.");
                        message.setCancelable(true);

                        message.setNegativeButton("Ok", null);
                        alert = message.create();

                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }


        else {
            checkdata.child("Emailid").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(dataSnapshot.child(id).exists())
                    {
                        loginuserwithemail(dataSnapshot.child(id).getValue().toString() ,id , pass);

                    }

                    else
                    {

                        handler.removeCallbacks(runnable);
                        loginprogressbar.setVisibility(View.GONE);
                        AlertDialog.Builder message = new AlertDialog.Builder(getContext());
                        message.setTitle("Message");
                        AlertDialog alert;
                        message.setMessage("Please Sign Up to use our service.");
                        message.setCancelable(true);

                        message.setNegativeButton("Ok",null);
                        alert = message.create();
                        alert.show();
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


        }
    }



    @RequiresApi(api = Build.VERSION_CODES.N)
    private void proceedlogin()
    {
        setprogress();
        loginprogressbar.setVisibility(View.VISIBLE);
        isNumeric = loginid.getText().toString().chars().allMatch( Character::isDigit );
        if (isNumeric)
        {
            checkblockeduserphoneno(loginid.getText().toString());
        }

        else
            {
            checkblockeduseremail(loginid.getText().toString().replace("@", "~").replace(".", "`"));
        }


    }


    @SuppressLint("ResourceAsColor")
    private void setprogress()
    {
        loginprogressbar.setColorSchemeResources(android.R.color.holo_green_light,android.R.color.holo_blue_dark,android.R.color.holo_orange_light,android.R.color.holo_red_light);
        runnable = new Runnable() {

            @Override
            public void run() {
                if(finalI *10>=90){

                }
                else {
                    loginprogressbar.setProgress(finalI * 10);
                }
            }
        };

        for (int i = 0; i < 10; i++) {
            finalI = i;
            handler.postDelayed(runnable,1000*(i+1));
        }


    }



}
