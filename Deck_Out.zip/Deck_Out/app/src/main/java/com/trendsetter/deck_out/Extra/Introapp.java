package com.trendsetter.deck_out.Extra;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.sachinvarma.easypermission.EasyPermission;
import com.sachinvarma.easypermission.EasyPermissionConstants;
import com.sachinvarma.easypermission.EasyPermissionInit;
import com.sachinvarma.easypermission.EasyPermissionList;
import com.trendsetter.deck_out.Homepage.homepage;
import com.trendsetter.deck_out.Login_Signup.MainActivity;
import com.trendsetter.deck_out.R;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Introapp  extends AppCompatActivity {


    TextView openloginsignup , openmain;
    List<String> permission;
    private SharedPreferences sp;
    private   SharedPreferences.Editor Ed;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.introlayout);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        openloginsignup = findViewById(R.id.loginsignupbtn);
        openmain = findViewById(R.id.mainbtn);

        openloginsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Introapp.this, MainActivity.class));
                Ed.putString("usertype", "#guest");
                Ed.commit();
            }
        });


        openmain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Introapp.this, homepage.class).putExtra("usertype", "#guest"));
                Ed.putString("usertype", "#guest");
                Ed.commit();
            }
        });

        sp=getSharedPreferences("Login", MODE_PRIVATE);
        Ed=sp.edit();

        permission = new ArrayList<>();
        permission.add(EasyPermissionList.READ_EXTERNAL_STORAGE);
        permission.add(EasyPermissionList.WRITE_EXTERNAL_STORAGE);
        permission.add(EasyPermissionList.ACCESS_NOTIFICATION_POLICY);
        permission.add(EasyPermissionList.BROADCAST_SMS);

    }

    @Override
    protected void onStart() {
        super.onStart();
        new EasyPermissionInit(Introapp.this, permission);
    }

    @Override
    public void onBackPressed() {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case EasyPermissionConstants.INTENT_CODE:

                if (data != null) {
                    boolean isGotAllPermissions =
                            data.getBooleanExtra(EasyPermissionConstants.IS_GOT_ALL_PERMISSION, false);

                    if(data.hasExtra(EasyPermissionConstants.IS_GOT_ALL_PERMISSION)){
                        if (isGotAllPermissions) {
                           /* Toast.makeText(this, "All Permissions Granted", Toast.LENGTH_SHORT).show();*/
                        } else {
                          /*  Toast.makeText(this, "All permission not Granted", Toast.LENGTH_SHORT).show();*/
                        }}

                    // if you want to know which are the denied permissions.
                    if (data.getSerializableExtra(EasyPermissionConstants.DENIED_PERMISSION_LIST) != null) {

                        ArrayList  deniedPermissions = new ArrayList<>();

                        deniedPermissions.addAll((Collection<? extends String>) data.getSerializableExtra(
                                EasyPermissionConstants.DENIED_PERMISSION_LIST));

                        if (deniedPermissions.size() > 0) {
                            for (int i = 0; i < deniedPermissions.size(); i++) {

                                    if(EasyPermissionList.READ_EXTERNAL_STORAGE == deniedPermissions.get(i)) {

                                        Toast.makeText(this, "Storage Permission not granted", Toast.LENGTH_SHORT)
                                                .show();

                                    }


                                if(EasyPermissionList.CAMERA == deniedPermissions.get(i)) {

                                    Toast.makeText(this, "Storage Permission not granted", Toast.LENGTH_SHORT)
                                            .show();

                                }

                            }
                        }
                    }
                }
        }
    }
}
