package com.trendsetter.deck_out.Orders;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.trendsetter.deck_out.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class myorderitemholder extends RecyclerView.ViewHolder
{
    ImageView itemimg;
    CardView cardView;
    LinearLayout trackorderbtn , cancelorderbtn ;
    TextView ordernametxt , ordertypetxt , orderpricetxt , orderquantntypetxt , orderstatustxt , orderOrdernotxt ;
    RelativeLayout trackandcancedlayout , myorderdetaillayout;

    public myorderitemholder(View itemView) {
        super(itemView);
        cardView = itemView.findViewById(R.id.myorderscard);

        trackorderbtn = itemView.findViewById(R.id.trackorderbtn);
        cancelorderbtn = itemView.findViewById(R.id.cancelorderbtn);

        itemimg = itemView.findViewById(R.id.myorderimage);

        ordernametxt = itemView.findViewById(R.id.ordername);
        ordertypetxt = itemView.findViewById(R.id.ordertype);
        orderpricetxt = itemView.findViewById(R.id.orderprice);
        orderquantntypetxt = itemView.findViewById(R.id.orderquantntype);
        orderstatustxt = itemView.findViewById(R.id.orderstatus);
        orderOrdernotxt = itemView.findViewById(R.id.orderOrderno);

        trackandcancedlayout = itemView.findViewById(R.id.trackandcancedlayout);
        myorderdetaillayout = itemView.findViewById(R.id.myorderdetaillayout);


    }




    public void opentrackorder(String orderitemname , String ordertype , String totalprice
            , ArrayList<String> trackdates , String orderno , String orderdeladdrs , Context context)
    {
        context.startActivity(new Intent(context, Trackorders.class).putExtra("itemname" , orderitemname).putExtra("itemtype" , ordertype)
                .putExtra("itemtprice" , totalprice).putExtra("itemtrackdates" , trackdates)
                .putExtra("itemorderno" , orderno).putExtra("itemorderdeladdrs" , orderdeladdrs));
    }


    public   void  cancelorder(String orderidtxt)
    {
        DatabaseReference trackupdatemsgref = FirebaseDatabase.getInstance().getReference("orderdetaillist/"+orderidtxt+"/iscancelled");
        trackupdatemsgref.setValue("#T");
    }


    public void openordersublist(Context context , String orderidtxt)
    {
        context.startActivity(new Intent(context,Myorderproductlist.class).putExtra("orderidcode" ,orderidtxt ));

    }

}